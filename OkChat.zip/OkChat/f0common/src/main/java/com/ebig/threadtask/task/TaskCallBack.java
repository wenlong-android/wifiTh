package com.ebig.threadtask.task;

public interface TaskCallBack {

    void call();
}
