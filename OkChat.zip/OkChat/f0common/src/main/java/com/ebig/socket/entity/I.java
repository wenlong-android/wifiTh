package com.ebig.socket.entity;

public class I {
    protected static final int I_1=1;
    protected static final int I_2=2;
    protected static final int I_3=3;
    protected static final int I_4=4;
    protected static final int I_5=5;
    protected static final int I_6=6;
    protected static final int I_7=7;
    protected static final int I_8=8;
    protected static final int I_9=9;
    protected static final int I_10=10;
    protected static final int I_11=11;
    protected static final int I_12=13;
}
