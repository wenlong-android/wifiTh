package com.ebig.socket.idl;

public interface SenderColorLightListenner extends SenderListenner {
    void ok();
}
