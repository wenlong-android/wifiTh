package com.ebig.common;

import android.os.Environment;

import com.ebig.utils.TimeUtils;

public class BaseCommon {
    public final static String STORAGE_PATH = Environment.getExternalStorageDirectory() + "/YDZN_LOG/";
    public final static String INSTALL_PROVIDER="com.ebig.update.fileprovider";
    public final static String INSTALL_DATA_TYPE="application/vnd.android.package-archive";
    //超级管理员账号
    public final static String superAccount="admin";
    //超级管理员动态密码 当前时间 小时+分钟倒序 如：9点32分钟 ，密码为2390
    public static String uperPassWord(){
        StringBuilder sb=new StringBuilder();
        sb.append(TimeUtils.getHourMinute());
        return sb.reverse().toString();
    }


}
