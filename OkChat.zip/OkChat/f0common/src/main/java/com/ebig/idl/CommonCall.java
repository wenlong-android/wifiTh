package com.ebig.idl;

public interface CommonCall<T> {
    void onCommonCall(T t);
}
