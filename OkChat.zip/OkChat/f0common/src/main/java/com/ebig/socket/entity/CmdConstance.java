package com.ebig.socket.entity;

public class CmdConstance {
    /*应答*/
    public static final String C_81="81";
    public static final String C_01="01";
    /*开锁*/
    public static final String C_83="83";
    public static final String C_03="03";
    /*读卡器*/
    public static final String C_84="84";
    public static final String C_04="04";
    /*上报状态*/
    public static final String C_86="86";
    public static final String C_06="06";
    /*背光*/
    public static final String C_88="88";
    public static final String C_08="08";
    /*LCD*/
    public static final String C_89="89";
    public static final String C_09="09";
    /*温湿度*/
    public static final String C_8d="8d";
    public static final String C_0d="0d";
    /*扫描头*/
    public static final String C_8f="8f";
    public static final String C_0f="0f";
    /*指静脉*/
    public static final String C_90="90";
    public static final String C_10="10";
    /*三色灯*/
    public static final String C_15="15";
    public static final String C_95="95";
    /*开锁*/
    public static final String C_7e="7e";
    public static final String C_7f="7f";
    public static final String C_be="be";

    /*电子秤*/
    public static final String C_8E="8e";
    public static final String C_0E="0e";

    /*0长度*/
    public static final String C_00="00";
    public static final String C_02="02";
    public static final String C_05="05";
    public static final String C_07="07";
    public static final String C_0a="0a";
    public static final String C_0b="0b";
    public static final String C_0c="0c";
    public static final String C_0e="0e";
    public static final String C_11="11";
    public static final String C_12="12";
    public static final String C_13="13";
    public static final String C_14="14";
    public static final String C_16="16";
    public static final String C_17="17";
    public static final String C_18="18";
    public static final String C_19="19";
    public static final String C_20="20";
    public static final String C_21="21";
    public static final String C_22="22";
    public static final String C_23="23";
    public static final String C_24="24";
    public static final String C_25="25";
    public static final String C_26="26";
    public static final String C_27="27";
    public static final String C_28="28";
    public static final String C_29="29";
    public static final String C_2a="2a";
    public static final String C_2b="2b";
    public static final String C_2c="2c";
    public static final String C_2d="2d";
    public static final String C_2e="2e";
    public static final String C_2f="2f";

    public static final String C_30="30";
    public static final String C_31="31";
    public static final String C_32="32";
    public static final String C_33="33";
    public static final String C_34="34";
    public static final String C_35="35";
    public static final String C_36="36";
    public static final String C_37="37";
    public static final String C_38="38";
    public static final String C_39="39";
    public static final String C_3a="3a";
    public static final String C_3b="3b";
    public static final String C_3c="3c";
    public static final String C_3d="3d";
    public static final String C_3e="3e";
    public static final String C_3f="3f";

    public static final String C_40="40";
    public static final String C_41="41";
    public static final String C_42="42";
    public static final String C_43="43";
    public static final String C_44="44";
    public static final String C_45="45";
    public static final String C_46="46";
    public static final String C_47="47";
    public static final String C_48="48";
    public static final String C_49="49";
    public static final String C_4a="4a";
    public static final String C_4b="4b";
    public static final String C_4c="4c";
    public static final String C_4d="4d";
    public static final String C_4e="4e";
    public static final String C_4f="4f";

    public static final String C_fb="fb";
    public static final String C_fe="fe";
    public static final String C_ff="ff";


    /*返回错误*/
    public static final String serverShutDown="---->本地服务端已关闭---->";
    public static final String clientLost="---->硬件客户端未连接 或 已断开---->";
    public static final String unKnown="---->未知错误---->";
    public static final String resendLimit= "---->达到超时重发上限---->";


    /*队列延迟时间*/
   public static final long  QUEUE_TIMER_DELAY=100;
    /*队列延迟时间*/
    public static final long QUEUE_TIMER_PERIOD=100;
}
