package com.ebig.socket.entity;

public class IT extends I{
    /*指令计算长度时没有数据区的默认长度*/
    public static final int CMD_DEFALUT_LEN=I_4;
}
