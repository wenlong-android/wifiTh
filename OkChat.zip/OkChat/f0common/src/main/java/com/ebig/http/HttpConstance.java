package com.ebig.http;

public class HttpConstance {
    /*请求成功*/
    public static final int SUCCESS=200;
}
