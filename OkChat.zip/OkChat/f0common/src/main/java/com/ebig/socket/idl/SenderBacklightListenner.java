package com.ebig.socket.idl;



public interface SenderBacklightListenner extends SenderListenner {
    void ok();
}
