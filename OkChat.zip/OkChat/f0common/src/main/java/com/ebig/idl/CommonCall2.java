package com.ebig.idl;

public interface CommonCall2<Result,Opposite> {
    void onCommonCall(Result result,Opposite opposite);
}
