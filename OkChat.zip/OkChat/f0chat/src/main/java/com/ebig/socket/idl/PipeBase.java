package com.ebig.socket.idl;
/*心跳*/
public interface PipeBase {

}
