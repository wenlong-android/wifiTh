package com.ebig.socket.dispatchWrite.base;

public interface BaseScanApiBase extends BaseCmdApi {
}
