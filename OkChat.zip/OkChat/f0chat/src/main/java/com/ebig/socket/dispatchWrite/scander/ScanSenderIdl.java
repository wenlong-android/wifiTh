package com.ebig.socket.dispatchWrite.scander;

import com.ebig.idl.CommonCall;

public interface ScanSenderIdl {
    public ScanAnSender scan(CommonCall<String> scanCall);
}
