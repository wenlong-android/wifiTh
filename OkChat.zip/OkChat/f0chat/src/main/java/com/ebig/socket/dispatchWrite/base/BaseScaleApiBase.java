package com.ebig.socket.dispatchWrite.base;

public interface BaseScaleApiBase extends BaseCmdApi {
}
