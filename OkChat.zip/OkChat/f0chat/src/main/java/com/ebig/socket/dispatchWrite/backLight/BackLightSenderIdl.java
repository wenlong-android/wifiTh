package com.ebig.socket.dispatchWrite.backLight;

public interface BackLightSenderIdl {

    public BackLightAnSender on();

    public BackLightAnSender off();


}
