package com.ebig.socket.idl;
/*心跳*/
public interface PipeCall extends PipeBase{
    void idel(long period);
}
