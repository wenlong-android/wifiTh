package com.ebig.socket.dispatchWrite.lcd;

public interface LcdSenderIdl {
    public LcdAnSender show(LcdParam param);
}
