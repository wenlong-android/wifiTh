package com.ebig.socket.dispatchRead.handler;

import com.ebig.socket.common.OkChat;
import com.ebig.socket.listenner.Listenner4Th;

import com.ebig.utils.DoubleUtils;
import com.ebig.utils.HexUtils;
import com.ebig.socket.entity.CmdResultInfo;
import com.ebig.socket.entity.CmdType;

import java.util.concurrent.ConcurrentHashMap;

/*温湿度*/
public class Handler4TH implements BaseHandler {
    private ChainHandler handler;
    private static ConcurrentHashMap<String,Long> thMap=new ConcurrentHashMap<>();
    @Override
    public void bind(ChainHandler baseHandler) {
        this.handler = baseHandler;
    }

    @Override
    public void onNextHanlder(CmdResultInfo info) {
        if (CmdType.isTHUp(info.getOrder())) {
            String th = info.getData();
            String temperature = th.substring(0, 4);
            String humidity = th.substring(4, 8);
            String fianlT = temperature.substring(2, 4) + temperature.substring(0, 2);
            String fianlH = humidity.substring(2, 4) + humidity.substring(0, 2);
            double temperatureInt = (HexUtils.hex2int(fianlT) * 175.72) / 65536.0 - 46.85;
            double humidityInt = (HexUtils.hex2int(fianlH) * 125.0) / 65536.0 - 6;
            long newTime=System.currentTimeMillis();
            long internal =0;
            if (thMap.containsKey(info.getHost())){
                long last=thMap.get(info.getHost());
                internal=newTime-last;
            }
            thMap.put(info.getHost(),newTime);
            OkChat.l().onThCall(temperatureInt, humidityInt, internal);
            double t = DoubleUtils.with2(temperatureInt);
            double h = DoubleUtils.with2(humidityInt);

            Listenner4Th.onThRecive(t, h, internal);


        } else {
            handler.nextIndex(info);
        }
    }
}
