package com.ebig.socket.common;

import com.ebig.socket.bean.HostInfo;

import java.util.concurrent.ConcurrentHashMap;

public class DeviceCenter {
    /**
     * 已绑定柜子ip过滤
     * 没有绑定的柜子信息一律过滤
     */
    public static ConcurrentHashMap<String, HostInfo> hashMap=new ConcurrentHashMap<>();
    public static void add(HostInfo info){
        if (info==null) {
            return;
        }
        hashMap.put(info.getHost(),info);
    }

    public static ConcurrentHashMap<String, HostInfo> getHashMap() {
        return hashMap;
    }

    public static boolean allow(String host){
        return hashMap.containsKey(host);
    }


    public static void remove(String host){
        hashMap.remove(host);
    }
}
