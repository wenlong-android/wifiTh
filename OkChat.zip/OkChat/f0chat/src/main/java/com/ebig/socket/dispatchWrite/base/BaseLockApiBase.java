package com.ebig.socket.dispatchWrite.base;

public interface BaseLockApiBase extends BaseCmdApi {
}
