package com.ebig.service;

public interface CmdCall {
    void onCall(String json);
}
