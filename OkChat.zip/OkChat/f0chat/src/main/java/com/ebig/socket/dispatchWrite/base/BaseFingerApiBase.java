package com.ebig.socket.dispatchWrite.base;

public interface BaseFingerApiBase extends BaseCmdApi {
}
