package com.ebig.socket.idl;
/*温湿度*/
public interface PipeIdelCall extends PipeBase{
    void onIdelCall(long internal);
}
