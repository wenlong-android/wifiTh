package com.ebig.socket.bean;

public class HostInfo {
    private String id;
    private String factoryCode;
    private String host;
    private String name;

    public HostInfo(String id, String factoryCode, String host, String name) {
        this.id = id;
        this.factoryCode = factoryCode;
        this.host = host;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFactoryCode() {
        return factoryCode;
    }

    public void setFactoryCode(String factoryCode) {
        this.factoryCode = factoryCode;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "HostInfo{" +
                "id='" + id + '\'' +
                ", factoryCode='" + factoryCode + '\'' +
                ", host='" + host + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
