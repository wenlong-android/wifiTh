package com.ebig.socket.dispatchWrite.scale;

import android.annotation.SuppressLint;

import com.ebig.socket.dispatchWrite.base.BaseScaleApiBase;

/*电子秤-读取数量*/
public class BaseScaleGetNumApiBase implements BaseScaleApiBase {
    @SuppressLint("WrongConstant")
    @Override
    public String getCmd() {
        //0x0A,0x00,0x00,0x00,0x00
        return "0a00000000";
    }
}
