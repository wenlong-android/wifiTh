package com.ebig.socket.dispatchWrite.colorLight;

import com.ebig.socket.dispatchWrite.base.BaseCmdApi;

public interface ColorLightApiBase extends BaseCmdApi {
}
