package com.ebig.socket.idl;

public interface PipeServerCall {
    void onResult(boolean isSuccess);
}
