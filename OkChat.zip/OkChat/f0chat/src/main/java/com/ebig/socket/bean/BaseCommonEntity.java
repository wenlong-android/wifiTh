package com.ebig.socket.bean;

public class BaseCommonEntity {

}
