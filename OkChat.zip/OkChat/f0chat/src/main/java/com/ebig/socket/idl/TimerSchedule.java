package com.ebig.socket.idl;

public interface TimerSchedule {
    void onSchedule();
}
