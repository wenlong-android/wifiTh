package com.ebig.socket.dispatchWrite.lcd;

public interface LcdParam {
     // String getFinalCmd();
//    private String mode;
//    private String content;

//    public LcdParam(@LcdC.D String mode, String content) {
//        this.mode = mode;
//        this.content = content;
//    }

//    public String getMode() {
//        return mode;
//    }
//
//    public void setMode(String mode) {
//        this.mode = mode;
//    }
//
//    public String getContent() {
//        return content;
//    }
//
//    public void setContent(String content) {
//        this.content = content;
//    }
    public String getFinalCmdString();
}
