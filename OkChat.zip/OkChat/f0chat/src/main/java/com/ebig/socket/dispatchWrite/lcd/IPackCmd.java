package com.ebig.socket.dispatchWrite.lcd;

public interface IPackCmd {
    String getFinalCmdString();
}
