package com.ebig.socket.listenner;
import com.ebig.idl.CommonCall2;



public class Listenner4Idel {
    private static CommonCall2<String,String> idelCall;

    public static void onRecive(String cargoId,String host) {
       if (idelCall!=null){
           idelCall.onCommonCall(cargoId,host);
       }
    }

    public static void setIdelCall(CommonCall2<String,String> call) {
        Listenner4Idel.idelCall = call;
    }
}
