package com.ebig.socket.dispatchWrite.base;

public interface BaseColorLightApiBase extends BaseCmdApi {
}
