package com.ebig.socket.bean;

public class CargoInfo {
    /**
     * 设备上有拨码键盘，后四位是柜体id号，
     * 可设置共31个柜体号（0不可取）
     * serial E001
     */
    private String id;
    private String serial;
    private String factoryCode;

    public CargoInfo() {
    }

    public CargoInfo(String id, String serial, String factoryCode) {
        this.id = id;
        this.serial = serial;
        this.factoryCode = factoryCode;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSerial() {
        return serial;
    }

    public void setSerial(String serial) {
        this.serial = serial;
    }

    public String getFactoryCode() {
        return factoryCode;
    }

    public void setFactoryCode(String factoryCode) {
        this.factoryCode = factoryCode;
    }

    @Override
    public String toString() {
        return "CargoInfo{" +
                "id='" + id + '\'' +
                ", serial='" + serial + '\'' +
                ", factoryCode='" + factoryCode + '\'' +
                '}';
    }
}
