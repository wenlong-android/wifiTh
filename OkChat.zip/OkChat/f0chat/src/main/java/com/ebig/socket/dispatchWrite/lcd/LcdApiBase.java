package com.ebig.socket.dispatchWrite.lcd;

import com.ebig.socket.dispatchWrite.base.BaseCmdApi;

public interface LcdApiBase extends BaseCmdApi {
}
