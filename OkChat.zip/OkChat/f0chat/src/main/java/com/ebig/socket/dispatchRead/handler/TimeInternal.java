package com.ebig.socket.dispatchRead.handler;

public class TimeInternal {
    public static long idelStart=0;
    public static long thStart=0;
}
