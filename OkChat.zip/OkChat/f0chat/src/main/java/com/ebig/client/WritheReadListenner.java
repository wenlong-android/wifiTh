package com.ebig.client;

public interface WritheReadListenner {
    void onWrite(String json);
    void onRead(String json);
}
