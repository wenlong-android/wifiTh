package com.ebig.socket.listenner;

public interface IListenner {
}
