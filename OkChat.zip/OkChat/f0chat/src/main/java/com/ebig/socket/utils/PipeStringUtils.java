package com.ebig.socket.utils;

public class PipeStringUtils {
    public static String getDouble2(double d) {
        return String.format("%.2f", d);
    }
}
