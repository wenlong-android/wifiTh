package com.ebig.socket.idl;

public interface SocketLifeActionCall {
    void onCreate();
    void onResume();
    void onDestory();
}
