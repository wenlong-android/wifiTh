package com.ebig.socket.dispatchWrite.colorLight;

public interface ColorLightIdl {
    ColorLightAnSender config(CLightParam param);
}
