package com.ebig.socket.listenner;

import com.ebig.idl.CommonCall;
import com.ebig.socket.bean.HostInfo;
import com.ebig.socket.common.DeviceCenter;
import com.ebig.utils.StrUtils;

public class BindHostListenner {

    private static CommonCall<String> commonCall;
    private static HostInfo HostInfo = null;

    public static void setCommonCall(HostInfo info, CommonCall<String> commonCall) {
        BindHostListenner.HostInfo = info;
        BindHostListenner.commonCall = commonCall;
    }

    public static void onRecive(String host, String id) {
        if (commonCall != null && StrUtils.objNotNull(HostInfo) && HostInfo.getId().equals(id)) {
            HostInfo.setHost(host);
            DeviceCenter.add(HostInfo);
            commonCall.onCommonCall(host);
        }
    }

    public static CommonCall<String> getCommonCall() {
        return commonCall;
    }

    public static void release() {
        commonCall = null;
        BindHostListenner.HostInfo = null;
    }


}
