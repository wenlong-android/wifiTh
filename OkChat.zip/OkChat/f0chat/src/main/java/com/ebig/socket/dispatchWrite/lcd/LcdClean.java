package com.ebig.socket.dispatchWrite.lcd;

public class LcdClean implements LcdParam{

    @Override
    public String getFinalCmdString() {
        return null;
    }
}
