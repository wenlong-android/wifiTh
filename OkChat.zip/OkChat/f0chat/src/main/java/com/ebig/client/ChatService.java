package com.ebig.client;

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;

import androidx.annotation.Nullable;

import com.ebig.idl.CommonCall;
import com.ebig.log.ELog;
import com.ebig.service.ICmdService;
import com.ebig.utils.StrUtils;
import com.minjie.libcmd.ITHServiceCall;
import com.minjie.libcmd.IthListenner;

public class ChatService extends Service implements ICmdService, CommonCall<String> {
    private String host;
    private int port;
    private ChatClient client;

    @Override
    public void onCreate() {
        super.onCreate();
        ELog.print("ChatClient onCreate:");
    }

    @Override
    public void onCommonCall(String json) {
        ELog.print("ChatClient onCommonCall:" + json);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        ELog.print("ChatClient onBind:");
        host = intent.getStringExtra("host");
        port = intent.getIntExtra("port", 0);
        if (StrUtils.notEmpty(host) && port != 0) {
            ELog.print("ChatClient ip:" + host + " port:" + port);
//            client = new ChatClient.Config(host, port).addReadCall(this).build();
//            client.start();
        }

        return serviceCall.asBinder();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    @Override
    public void begin(Context context) {

    }

    @Override
    public void onServiceConnected(ComponentName name, IBinder service) {

    }

    @Override
    public void onServiceDisconnected(ComponentName name) {

    }

    private ITHServiceCall serviceCall = new ITHServiceCall.Stub() {
        @Override
        public void regist(IthListenner call) throws RemoteException {

        }

        @Override
        public void sendJson(String json) {
            ELog.print("ChatClient sendJson:" + json+" client:"+client);
            if (client != null) {
                client.send(json);
            }
        }
    };
}
