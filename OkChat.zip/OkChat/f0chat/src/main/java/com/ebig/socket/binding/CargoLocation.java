package com.ebig.socket.binding;

import com.ebig.socket.entity.CmdResultInfo;

import java.util.HashMap;

public class CargoLocation {
    private static HashMap<String,String> locationMap=new HashMap<>();
    public static void put(String host, CmdResultInfo info){
        if (!locationMap.containsKey(host)){
            locationMap.put(host,info.getCmdArray().get(4));
        }
    }
    public static String getCargo(String host){
        if (!locationMap.containsKey(host)){
           return locationMap.get(host);
        }else {
            return "01";
        }
    }
}
