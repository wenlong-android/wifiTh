package com.ebig.socket.dispatchWrite.base;

public interface BaseCmdApi {
   String getCmd();
}
